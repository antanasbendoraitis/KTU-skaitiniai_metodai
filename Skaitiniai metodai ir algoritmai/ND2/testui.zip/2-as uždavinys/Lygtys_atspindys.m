%
%   atspindzio metodas
%
clc
% A = [3 8 1 4;
%      2 6 7 9;
%      4 6 5 1;
%      1 2 -6 -5]
%  b=[24;-1;15;25]
A=[ 5 3 -1 2;
   3 6 -2 -2;
   -1 -2 4 -1;
   2 -2 -1 12]
% coefficient matrix
b=[16; 7; -14; 38] 

n=size(A,1),  nb=size(b,2)
A1=[A,b];

det(A);

disp(' tiesioginis zingsnis(atspindziai)')
for i=1:n-1
    z=A1(i:n,i);
    zp=zeros(size(z)); zp(1)=norm(z);
    omega=(z-zp);  omega=omega/norm(omega);
    Q=eye(n-i+1)-2*omega*omega';
    A1(i:n,:)=Q*A1(i:n,:);
end

% Atvirkstinis zingsnis

x=zeros(n,nb);
for i=n:-1:1
    if (abs(A1(i,i)) < 1e-10) && (abs(det(A)) < 1e-10)
        x(i,:)=1;
    else
        x(i,:)=(A1(i,n+1:end)-A1(i,i+1:n)*x(i+1:n,:))/A1(i,i);
    end
end


disp('sprendinys x='),x'
disp('sprendinio patikrinimas:'),liekana=(A*x-b)'
disp('bendra santykine paklaida:'),disp(norm(liekana)/norm(x))
% for i=1:n-1
% z=A1(i:n,i);
% zAtspindetas=zeros(size(z));
% zAtspindetas(1)=sign(z(1))*norm(z);
% omega=(z-zAtspindetas);
% omega=omega/norm(omega);
% Q=eye(n-i+1)-2*omega*omega';
% A1(i:n,:)=Q*A1(i:n,:)
% end
% % Atvirkstinis etapas toks pats, kaip ir Gauso algoritmo:
% x=zeros(n,1);
% 
% x(n,:)=A1(n,n+1)/A1(n,n);
% for i=n-1:-1:1
% x(i,:)=(A1(i,n+1)-A1(i,i+1:n)*x(i+1:n,:))/A1(i,i);
% end
% x
% disp('sprendinio tikrinimas A*x-b')
% A*x-b