function GausoAlgoritmas
% Gauso algoritmas
clc
A=[3 7 1 1;
   1 -6 6 8;
   4 4 -7 4;
   -1 3 8 2]
b=[31;-5;33;-2]
% b=[2 1;0  2;9 3;7 3]
n=size(A,1),  nb=size(b,2)
A1=[A,b]
 
% Gauso algoritmo tiesioginis etapas:
for i=1:n-1
    for j=i+1:n,
        A1(j,i+1:n+nb)=A1(j,i+1:n+nb)-A1(i,i+1:n+nb)*A1(j,i)/A1(i,i);
        A1(j,i)=0;   
    end
    A1
end
 
% Gauso algoritmo atvirkstinis etapas:
x=zeros(n,nb);
for i=n:-1:1
    x(i,:)=(A1(i,n+1:end)-A1(i,i+1:n)*x(i+1:n,:))/A1(i,i);
end
 
disp('sprendinys x='),x
disp('sprendinio patikrinimas:'),liekana=A*x-b
disp('bendra santykine paklaida:'),disp(norm(liekana)/norm(x))
 
%tikrinimas
X = linsolve(A,b)
end
