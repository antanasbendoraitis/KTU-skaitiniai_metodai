%  Gauss-Jordan elimination
%

clc
fprintf(1,'koeficientu matrica :')
A=[  3 7 1 3; 1 -6 6 5; 4 4 -7 1; 4 16 2 0]
fprintf(1,'laisvuju nariu vektorius :')
b=[40; 19; 36; 48]


n=size(A,1);  
fprintf(1,' Lygciu skaicius %d  \n',n);
fprintf(1,' matrica A ir vektorius b sublokuojami :')
A1=[A,b]

fprintf(1,' *******    Tiesioginis zingsnis: ********** \n')
for i=1:n-1
    [a,iii]=max(abs(A1(i:n,i))); % parenkamas vedantis elementas:
        if a == 0, 
            fprintf(1,'!!!!!!  vedantis elementas = %g,  ciklas praleidziamas \n',a)
            continue 
        end
    fprintf(1,'vedantis elementas %g,  lygties nr. %d \n',a,iii+i-1)
        if iii > 1  % eilutes sukeiciamos vietomis
            fprintf(1,'eilutes sukeiciamos vietomis :')
            A1([i,i+iii-1],:)=A1([i+iii-1,i],:); 
            A1
        end
    for j=i+1:n
        A1(j,i:n+1)=A1(j,i:n+1)-A1(i,i:n+1)*A1(j,i)/A1(i,i);   
    end
    fprintf(1,'vedanciojo elemento eilute atimama is zemiau esanciu :')
    A1
  %  input('Press Enter')
end

disp('Darome nulius virs istrizaines');
for i=n:-1:1
    for j=1:i-1
        A1(j, 1:n+1) = A1(j, 1:n+1) - A1(i, 1:n+1)*A1(j,i)/A1(i,i);   
    end
    A1
end

disp('Daliname, kad gautumeme identity-matrix');
for i=1:n
    A1(i, 1:n+1) = A1(i, 1:n+1) / A1(i,i)
    x(i)=A1(i, n+1);
end
liekana=A*x-b;
disp('sprendinys x='), disp(x')
disp('sprendinio patikrinimas (liekana=A*x-b):'), disp(liekana')
disp('bendra santykine paklaida:'),disp(norm(liekana)/norm(x))