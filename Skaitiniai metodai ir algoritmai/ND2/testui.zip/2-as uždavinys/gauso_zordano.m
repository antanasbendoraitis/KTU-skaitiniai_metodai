function maiklas
tolerance = 1e-9;

A=[1 1 1 1;
    1 -1 -1 1;
    2 1 -1 2;
    3 1 2 -1]
b=[2;0;9;7]

A=[A,b];


[rows,cols] = size (A);

r = 1;
for c=1:cols
    % Find the pivot row
    [m, pivot] = max (abs (A (r:rows, c)));
    pivot = r + pivot - 1;
        
        % Swap current row and pivot row
        A ([pivot, r], c:cols) = A ([r, pivot], c:cols);
        
        % Normalize pivot row
        A (r, c:cols) = A (r, c:cols) / A (r, c);
        
        % Eliminate the current column
        ridx = [1:r-1, r+1:rows];
        A (ridx, c:cols) = A (ridx, c:cols) - A (ridx, c) * A(r, c:cols);
        
		if (r == rows)
			break;
		end
		
        r = r+1;
end



A
end