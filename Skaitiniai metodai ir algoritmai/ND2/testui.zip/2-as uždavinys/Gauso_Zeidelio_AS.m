clc, clear all
A=[ 
  2  5  1  2;
 -3 -4  1  1
 -2  0  3  5;
  1  0 -1  1]
b=[14; -6; 10; 4]

n=size(A,1)
Aprad=A;

alpha=[8; -8; 1; 2];  % laisvai parinkti metodo parametrai

% Matrica kurios istrizainej 1-alfa.
Atld=diag(1./diag(A))*A-diag(alpha)
% B matrica kuri padalinta is A isstrizainiu (B_k / A_kk)
btld=diag(1./diag(A))*b
nitmax=1000;
% Tikslumas
eps=1e-12;
x=zeros(n,1);x1=zeros(n,1);
fprintf(1,'\n sprendimas iteracijomis:'); 
for it=1:nitmax
    for i=1:n
        x1(i)=(btld(i)-Atld(i,1:i-1)*x1(1:i-1)-Atld(i,i:n)*x(i:n))/alpha(i);
    end
  prec(it)=norm(x1-x)/(norm(x)+norm(x1));
  fprintf(1,'iteracija Nr. %d,  tikslumas  %g\n',it,prec(it))
  if prec(it) < eps, break, end
  x=x1;
end
disp('Atsakymas:')
x
disp('Patikrinimas')
Aprad*x-b

semilogy([1:length(prec)],prec,'r.');grid on,hold on
