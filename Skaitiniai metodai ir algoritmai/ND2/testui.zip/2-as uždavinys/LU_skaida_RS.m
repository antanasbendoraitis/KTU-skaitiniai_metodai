% LU skaida
function laoras_15_LU_skaida
    clc, close all, clear all
    
    A=[2 3 1 1;
       0 2 1 3;
       7 -4 1 1;
       1 -12 1 1]
    b=[12;5;6;-36]
 
    A1=A; b1=b;  
    n=size(A, 1)
    P=[1:n]
 
    %tiesioginis zingsnis
    for i=1:n-1 
       [a, iii]=max(abs(A1(i:n,i))); 
       A1([i,iii+i-1], :)=A1([iii+i-1,i], :);
       P([i,iii+i-1])=P([iii+i-1,i])       
       for j=i+1:n 
           r = A1(j, i)/A1(i, i);
           A1(j,i+1:end)=A1(j,i+1:end)-A1(i,i+1:end)*r;
           A1(j,i)=r;       
       end       
    end
 
    %atvirkstinis zingsnis
    b1=b1(P);
    for i=2:n 
      b1(i)=(b1(i)-A1(i, 1:i-1)*b1(1:i-1));
    end
 
    for i=n:-1:1
       b1(i)=(b1(i)-A1(i, i+1:n)*b1(i+1:n))/A1(i,i);
    end
    b1
    % tikslumo tikrinimas
    liekana=A*b1-b;
    liekana
 
    %tikrinimas su MatLab funkcija
    X = linsolve(A,b)
end
