%
% skenavimo ir pusiaukirtos metodai
% 
function skenuotiPusiaukirta
clc, close all
syms x
f1 = exp(-x)*sin(x.^2)+0.001;
f2 = subs(f1, x, -x);
xmin=5; xmax=10; nst=400;
x=[xmin :(xmax-xmin)/nst : xmax];
figure(1);grid on;hold on;
h1 = plot(x,funkcija(x),'b-');

funk = f1;

%-------------------skenavimas
Intervalai = [];
xPrad = 5;
xGal = 10;
SkanZingsnis = 0.001;
h = SkanZingsnis; % skenavimo zingsnis

prevX = xPrad;
nextX = prevX + h;
h4 = plot(prevX, 0, 'g>');
h5 = plot(nextX, 0, 'g<');
while(nextX < xGal)    
    delete(h4);
    delete(h5);
    if(funkcija(prevX)*funkcija(nextX) >= 0 )
        prevX = nextX;
        nextX = prevX+h;
    else
        Intervalai = [Intervalai prevX nextX]
        plot(prevX, 0, 'g>');
        plot(nextX, 0, 'g<');
        prevX = nextX;
        nextX = prevX+h;        
    end        
    h4 = plot(prevX, 0, 'g>'); 
    %input('press enter')
    h5 = plot(nextX, 0, 'g<');    
    %input('press enter')
    figure(1);    
end
delete(h4);
delete(h5);


%pusiaukirtos metodas
Sprendiniai = [];

eps = 1e-9;
kiekis = length(Intervalai)/2
for i=1:kiekis
    xK = Intervalai(i*2-1);
    xD = Intervalai(i*2);
    xvid = (xK+xD)/2;
    maxIter = 1000;
    iterSk =0;
    h7 = plot(xK, 0, 'k>');
    h8 = plot(xvid, 0, 'ro');
    h9 = plot(xD, 0, 'b<');

    while(abs(funkcija(xvid))>=eps )
        delete(h7);
        delete(h8);
        delete(h9);
        if(sign(funkcija(xvid)) == sign(funkcija(xK)))
            xK = xvid;
        elseif (sign(funkcija(xvid)) == sign(funkcija(xD)))
            xD = xvid;
        end
        xvid = (xK+xD)/2;
        h7 = plot(xK, 0, 'r>');
        h9 = plot(xD, 0, 'r<');
        h8 = plot(xvid, 0, 'rp');
        %input('press enter')
        figure(1)
        iterSk=iterSk+1;
        fprintf(1, 'iteracija= %g    tikslumas= %g \n', iterSk, abs(funkcija(xvid)));
        if(iterSk >= maxIter)
            break;
        end
    end
    fzero('exp(-x).*sin(x.^2)+0.001',xvid)
    Sprendiniai = [Sprendiniai xvid]
end
%Roots = roots(sym2poly(funk))
end

function rez = funkcija(x)
    rez = exp(-x).*sin(x.^2)+0.001;
end
