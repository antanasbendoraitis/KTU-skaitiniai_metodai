function ND11Skanavimas(f, xBounds, stepSize, points, figureNo)
    format long;
    %------------------ Grafikas-------------------------------------------
    x = xBounds(1): ( xBounds(2) - xBounds( 1)) / (points - 1) : xBounds(2);

    figure(figureNo); 
    plot( x, eval(f), 'b-');
    grid on; 
    hold on;
    %------------------/Grafikas-------------------------------------------
    
    eps = 1e-10;
   
    xLeft = xBounds(1);
    
    stepLineUp = max( eval(f)); 
    stepLineDown = min( eval(f));
    plot( [xLeft, xLeft], [stepLineUp, stepLineDown], 'r-') % kairys bruk�nys
    iterNo = 0;
    while xLeft <= xBounds(2) % kol nepasiekta grafiko de�in� - skenuojam vis� grafik�
        prec = 1;
        step = stepSize;
        stepPrev = step;
        while prec > eps && xLeft <= xBounds(2); %kol nepasiektas tikslumas arba grafiko kra�tas
            iterNo = iterNo + 1;
            fprintf('----------------- Nauja iteracija nr= %g ----------------------\n', iterNo);
            xRight = xLeft + step;
             
            x = xLeft;
            leftSign = sign( eval(f));            
            x = xRight;
            rightSign = sign( eval(f));
            while leftSign ~= rightSign, % jei funkcij� �enklai nebesutampa
                stepPrev = step; % saugom per didelio �ingsnio dyd�, reik�s galutinai radus �akn�
                step = step / 5; % suma�iname �ingsn� 5 kartus
                fprintf('Ma�inam �ingsn�, �enklai= [%g; %g] naujas �ingsnis = %g \n', leftSign, rightSign, step);
                xRight = xLeft + step;
                x = xRight;
                rightSign = sign( eval(f));
            end
            plot( [xRight, xRight], [stepLineUp, stepLineDown], 'r-'); % pie�iamas de�inys bruk�nys
            prec = abs( eval(f) * (xRight - xLeft));
            
            fprintf('Intervalas = [%25.15g; %25.15g] tikslumas = %g\n\n', xLeft, xRight, prec);
            xLeft = xRight;
            pause;
        end
        if xLeft <= xBounds(2),
            fprintf('Tikslumas pasiektas, �aknis yra intervale.\n');
            plot( (xLeft + xRight) / 2, 0, 'bo'); % nupie�iam intervalo vidurio ta�k�
            xLeft = xLeft + stepPrev; % pridedam anks�iau buvus� �ingsnio dyd�, kad per�okti �aknies ta�k�
        end
    end
    fprintf('Paie�ka baigta.\n');
end