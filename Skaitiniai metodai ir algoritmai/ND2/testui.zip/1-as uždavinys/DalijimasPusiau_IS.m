function DalijimasPusiau
    clc, close all, clear all
    
    %
    % NEBAIGTAS
    %
    
    %f = inline('x.^4-6*x.^3+3*x.^2+10*x');
    %xmin = -4;
    %xmax = 6;
    
    f=inline('sin(x) * (x.^2 - 1) * (x + 3) - 0.9;');
    xmin = -10;
    xmax = 10;
    
    eps = 1e-10;
    
    x = xmin:0.001:xmax;
    figure(1); grid on; hold on;
    h1 = plot(x,f(x),'r-');
    
    x1 = -3;
    x2 = -0.7;
    h(1) = plot(x1,0,'bp');
    h(2) = plot(x2,0,'kp');
    
    while 1
        xmid = (x1 + x2) / 2; 
        h(3) = plot(xmid,0,'ro');
        
        fprintf('Saknis x=%.10f (tikslumas %.10f)\n', xmid, abs((x2 - x1) / 2));
        
        if abs((x2 - x1) / 2) <= eps, break, end
        
        pause(0.1)

        if sign(f(xmid)) == sign(f(x1)) 
			x1 = xmid; 
		else
			x2 = xmid; 
		end
		
        delete(h(1:2)); 
		h(1) = plot(x1,0,'bp');
		h(2) = plot(x2,0,'mp');
        delete(h(3));
    end

    if abs((x2 - x1) / 2) > eps
        fprintf('\nTikslumas nepasiektas!\n');
    else
        fprintf('\nTikslumas pasiektas.\n');
    end
    
end
