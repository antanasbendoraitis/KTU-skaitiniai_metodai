%
% skenavimo metodas
% 
function skenuoti
clc, close all
syms x
% f1 = x.^4-3.*x.^3-(111/4).*x.^2-7.*x+147/4;
 f1 = x.^3-22.*x.^2+59.*x-38;
f2 = subs(f1, x, -x);
xmin=-10; xmax=20; nst=10000;
x=[xmin :(xmax-xmin)/nst : xmax];
figure(1);grid on;hold on;
h1 = plot(x,funkcija(x),'b-');

% f=x^3-22*x^2+59*x^1-38;
funk = f1;

%-------------------skenavimas
Saknys = [];
eps = 1e-9
%xPrad = real(-Rneig);
%xGal = real(Rteig)
xPrad = -10;
xGal = 20;
SkanZingsnis = 1;
h = SkanZingsnis; % skenavimo zingsnis
prevX = xPrad;
nextX = prevX + h;
h4 = plot(prevX, 0, 'go');
h5 = plot(nextX, 0, 'go');
sk=0;
while(nextX < xGal)
    while((abs(funkcija(prevX))>eps) && (nextX < xGal))
    %delete(h4);
    %delete(h5);
    if(sign(funkcija(prevX)) == sign(funkcija(nextX)))
       prevX = nextX;
       nextX = prevX+h;
    else
       h=h/2;       
       nextX=prevX+h;
       
    end       
    h4 = plot(prevX, 0, 'g>');   
    h5 = plot(nextX, 0, 'go');
    sk=sk+1;
    figure(1);
    end
    if(abs(funkcija(prevX))<eps)
        plot(prevX, 0, 'ro');
        Saknys = [Saknys prevX];
        saknis = prevX
        h = SkanZingsnis;
        prevX=prevX+h;        
        nextX=prevX+h;
        saknis = prevX;
        sk=sk
    end    
end
delete(h4);
delete(h5);
Saknys
Roots = roots(sym2poly(funk))

end

function rez = funkcija(x)
    %rez = x.^4-3.*x.^3-(111/4).*x.^2-7.*x+147/4;
    rez = x.^3-22.*x.^2+59.*x-38;
end