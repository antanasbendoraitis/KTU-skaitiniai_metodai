function Daugianaris_Niutono
clc, close all
grid on; hold on; % axis equal;
format 
realmax;

syms f x 

% Funkcija
f='x.^3-x.^2-30*x';
% Pradinis artinys

x0=7;
% Iteraciju maximumas
maxIterac=100; 
beta=1 ; 
% Reikalaujamas tikslumas
eps=1e-9;  
% I�vestin�
df=diff(eval(f),x);  
% Vaizdavimo reziai
x=[-7:0.01:7];

figure(1);
plot(x0, 0, 'cp');
plot(x,eval(f),'b-');

xn=x0;prec=1;nit=0;
while prec > eps    % iteracijos 
    nit=nit+1;
    if nit > maxIterac, fprintf('Virsytas leistinas iteraciju skaicius');break;end
    % Apskai�iuoja funkcij� ir jos i�vestin�
    x=xn;fxn=eval(f);dfxn=eval(df);
    xn1=xn-beta*fxn/dfxn;
    plot([xn,xn,xn1],[0,fxn,0],'g-');
    plot(xn1,0,'mp');
    xn=xn1; % Tam kad i�likt� ir ankstensn� reik�m� ir b�t� galima b��ti linij�.   
    pause();
    % Apskai�iuojama reik�m� ir �vertinamas tikslumas
    x=xn;fxn=eval(f);prec=abs(fxn);
    fprintf(1,'Iteracija %d  x = %6.14f  Tikslumas = %g \n',nit,xn,prec);
end
plot(xn,fxn,'k*');plot(xn,fxn,'ko');
fprintf(1,'\nApytiksl� reik�m� x = %6.14f rasta po %d iteracij�\n',xn,nit);
end


