function Funkcija_Stygu
clc,close all
grid on; hold on;

% Funkcija
f='exp(-x).*cos(x).*sin(x.^2-1)';
% Iteraciju maximumas
maxIterac=100;
% Reikalaujamas tikslumas
eps=1e-12;  
% Vaizdavimo reziai
x=[7:0.01:8];

figure(1);
plot(x,eval(f),'b-');

% Keli reikalingi kintamieji
range=[7, 8];
prec=1;
xRear=7.4;
xFront=7.6;


iteracija=0;
while prec > eps
    iteracija=iteracija+1;
    if iteracija > maxIterac, fprintf('Virsytas leistinas iteraciju skaicius');break;end
    plot(xRear,0,'mp');h = findobj(gca,'Type','line');h1=h(1);
    plot(xFront,0,'cp');h = findobj(gca,'Type','line');h2=h(1);       
    x=xRear;fRear=eval(f);x=xFront;fFront=eval(f);
    k=abs(fRear/fFront);xMid=(xRear+k*xFront)/(1+k);
    plot(xMid,0,'gs');plot([xRear,xFront],[fRear,fFront],'g-');h = findobj(gca,'Type','line');h3=h(1:2);

    x=xMid;fMid=eval(f);
    
    % Tikrinimas prasideda nuo kairiojo ta�ko
    x=xRear;fRear=eval(f);
    if sign(fMid) == sign(fRear), xRear=xMid;
    else, xFront=xMid;
    end
    
    % Tikrinimas prasideda nuo de�iniojo ta�ko
%     x=xFront;fFront=eval(f);
%     if sign(fMid) == sign(fFront), xFront=xMid;
%     else, xRear=xMid;
%     end
        
    pause()
    delete(h1);delete(h2);delete(h3);
    
    prec=abs(fMid); 
    fprintf(1,'Iteracija %d  x = %6.14f  Tikslumas = %g \n',iteracija,xMid,prec);
end
plot(xMid,0,'k*');plot(xMid,0,'ko');
fprintf(1,'\nApytiksl� reik�m� x = %6.14f rasta po %d iteracij�\n',xMid,iteracija);

end
