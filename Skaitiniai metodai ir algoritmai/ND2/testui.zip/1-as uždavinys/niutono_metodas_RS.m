function niutono_metodas
clc, close all, clear all
 
syms f x;
f = exp(-x.^2).*sin(x.^2).*(x+2);
df = diff(f, x)
 
ff = inline(char(f), 'x')
dff = inline(char(df), 'x')
 
xx = [-3:0.01:3];
 
hold on, grid on, axis equal
plot(xx, subs(f, x, xx), 'b-')
 
%x0 = -2.3;
%x0 = -1.9;
%x0 = -1.8;
%x0 = 1.8;
x0 = 2.5;
alpha = 1;
prec = 1e-9;
 
nit=0;
while 1
   nit=nit+1;
   fprintf('Iteracija %d ', nit);    
   prec1 = abs(ff(x0));
   plot(x0, 0, 'rp');
   plot([x0, x0], [0 ff(x0)], 'g-')
   fprintf(1, 'tikslumas=%g\n', prec1);
   if prec1 < prec, break, end
   x = x0 - alpha * ff(x0) / dff(x0);
   pause(0.2);
   plot([x0 x], [ff(x0), 0], 'g-')
   x0 = x;
end
 
fprintf(1, '\nrezultatas=%g\n', x0);
 
    f='exp(-x.^2).*sin(x.^2).*(x+2)';
    %range=[-3 -2.5];
    %range=[-3 -2];
    %range=[-3 -1]
    %range=[1 1.9]
    range=[2  3]
    testas = fzero(f, range); testas
end

