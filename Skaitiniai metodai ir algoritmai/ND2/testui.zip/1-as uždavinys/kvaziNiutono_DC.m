function ND11NiutonoKirstiniu(f, xBounds, points, figureNo)
    syms x
    %------------------------PRADINIAI DUOMENYS----------------------------
    delta = 1;
    x0 = xBounds(1);
    fprintf('pradinis artinys x0=%g\n', x0)
    xNow = x0 + delta;
   
    maxIters = 1000; % parenkame didziausia leistina iteraciju skaiciu
    eps = 1e-9;  % Parenkame tiksluma

    % kuriamas funkcijos grafikas:
    figure(figureNo); 
    grid on; 
    hold on; 
    title( [char(f), '=0']);
    
    % simbolinis x keiciamas reiksmemis is parinkto funkcijos vaizdavimo intervalo 
    x = xBounds(1): ( xBounds(2) - xBounds( 1)) / (points - 1) : xBounds(2);
    %------------------------/PRADINIAI DUOMENYS---------------------------
    
    
    
    %---------------- Braizomas funkcijos grafikas-------------------------
    plot( x, eval(f), 'r-'); % funkcija
    plot(xBounds, [0 0], 'm-'); % intervalas
    plot( x0, 0, 'mp'); % pradinis artinys
    h = findobj( gca, 'Type', 'line'); % suranda visus nupie�tus objektus pagal parametrus
    h1 = h(1); % pasiimam pirm�j� objekt�
    %----------------/Braizomas funkcijos grafikas-------------------------


    
    %------------------------ SPRENDIMAS-----------------------------------
    prec   = 1;
    iterNo = 0;
    while prec > eps    
        pause
        iterNo = iterNo + 1; % iteracijos 
        if iterNo > maxIters, fprintf('Virsytas leistinas iteraciju skaicius');
            break;
        end
        
        % skai�iavimai
        dfx = ( subs(f, 'x', xNow) - subs(f, 'x', x0)) / (xNow - x0);
        xNext = xNow - subs(f, 'x', xNow) / dfx; % kirstini� formul�

        % pie�imas
        plot( [xNow, xNow], [0, subs(f, 'x', xNow)], 'g-');
        plot( [xNow, xNext], [subs(f, 'x', xNow), 0], 'b-');
        delete(h1);
        plot( xNext, 0, 'mp');
        h = findobj(gca, 'Type', 'line');
        h1 = h(1);
        
        % keitimai
        x0 = xNow;
        xNow = xNext;
        fxNow = subs(f, 'x', xNow); % susiskai�iuojam funkcijos reik�m�
        
        prec = abs(fxNow);
        fprintf(1, 'iteracija %d  x= %g  prec= %15.15g \n', iterNo, xNow, prec);
    end
    plot( xNow, fxNow, 'k*');
    plot( xNow, fxNow, 'ko');
    fprintf( 1, 'sprendinys x= %g  tikslumas= %g \n', xNow, prec);
    %------------------------/SPRENDIMAS-----------------------------------
end