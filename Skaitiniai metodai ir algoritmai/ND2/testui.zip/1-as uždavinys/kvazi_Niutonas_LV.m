%
% Vienos lygties sprendimas: kvazi-Niutono metodu
% 

function kvazi_Niutonas
clc, close all

syms f x 


f=sin(x) .* x * 2  - (x/2 + 2) .^ 2

x0=-10;

deltax=0.01;
range=[-10,10];


eps=1e-9;

% braizomas funkcijos grafikas
npoints=100

xrange=range(1): (range(2)-range(1))/(npoints-1) :range(2);  
figure(1); grid on; hold on;
title([char(f),'=0;']);

plot(xrange,eval(subs(f,x,sym(xrange))),'r-');
plot(range,[0 0],'b-');
plot(x0,0,'mp');
h = findobj(gca,'Type','line');
h1=h(1);

% lygties sprendimas
xn=x0;
prec=1;

fxn=eval(subs(f,x,sym(xn)));
fxn_1=eval(subs(f,x,sym(xn+deltax)));
dfxn=(fxn_1-fxn)/deltax

nit=0;
nitmax=100;
while prec > eps 
    nit=nit+1;
    if nit > nitmax
        fprintf('Virsytas leistinas iteraciju skaicius');
        break;
    end

    xn1=xn-fxn/dfxn;   
    plot([xn,xn,xn1], [0,fxn,0], 'g-');
    delete(h1);
    plot(xn1,0,'mp');
    h = findobj(gca,'Type','line');
    h1 = h(1);
    fxn1 = eval(subs(f,x,sym(xn1)));
    dfxn = (fxn1-fxn)/(xn1-xn);
    xn=xn1;
    fxn=fxn1;

     pause
%     input('Press Enter'), figure(1);

    fxn=eval(subs(f,x,sym(xn)));
    prec=abs(fxn);
    fprintf(1,'iteracija %d  x= %g  prec= %g \n',nit,xn,prec);
end
plot(xn,fxn,'k*');
plot(xn,fxn,'ko');
xn
nit


% ................................................................................
disp('.... Patikriname saknies reiksme, naudodami MATLAB funkcija fsolve: ....')
fprintf('\n')
    
 x0=-10;  sprendinys = fsolve(char(f),x0); fprintf(1,'\npradinis artinys  x0=%g,  sprendinys=%g',x0,sprendinys);
 x0=-6;   sprendinys = fsolve(char(f),x0); fprintf(1,'\npradinis artinys  x0=%g,  sprendinys=%g',x0,sprendinys);
 x0=-3;   sprendinys = fsolve(char(f),x0); fprintf(1,'\npradinis artinys  x0=%g,  sprendinys=%g',x0,sprendinys);
 x0=-1;   sprendinys = fsolve(char(f),x0); fprintf(1,'\npradinis artinys  x0=%g,  sprendinys=%g',x0,sprendinys);
 fprintf(1,'\n');
end
 


