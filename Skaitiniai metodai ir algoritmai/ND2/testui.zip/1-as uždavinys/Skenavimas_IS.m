%
% Vienos lygties sprendimas: Skenavimo metodas
% 
function Skenavimas
    clc,close all

    syms f x   

    eps = 1e-4;
    step = 0.5;
    
    f = x.^4 - 6 * x.^3 + 3 * x.^2 + 10*x;
    xmin = -4;
    xmax = 6;
    
%     f = sin(x) * (x.^2 -1) * (x + 3) - 0.9;
%     xmin = -10;
%     xmax = 10;
    
    npoints = 1000;
    xrange = xmin : (xmax-xmin)/(npoints-1) : xmax;
    
    figure(1); grid on; hold on;
    str = [char(f),' = 0;   Skenavimo metodas'];
    title(str);
    h1 = plot(xrange,eval(subs(f,x,sym(xrange))),'r-');
    h2 = plot([xmin xmax],[0 0],'b-');
    h(1) = plot(xmin,0,'b>','MarkerFaceColor','b');
    h(2) = plot(xmin+step,0,'k<','MarkerFaceColor','k');
    
    legend([h1,h2,h(1),h(2)], 'funkcijos grafikas', 'f-jos x = 0 grafikas', 'intervalo pradzia', 'intervalo pabaiga');

    xn = xmin;
    nit = 0;
    tstep = step;
    
    input('Press ENTER to begin'), figure(1);

    while xn <= xmax
        nit = nit + 1;
        fprintf('Iteracija %4d      x = %15.10f      tikslumas %15.10f\n', nit, (xn+xn+tstep)/2, abs(tstep/2));
        
        delete(h(1:2));
        h(1) = plot(xn,0,'b>','MarkerFaceColor','b');
        h(2) = plot(xn+tstep,0,'k<','MarkerFaceColor','k');
        
        if sign(eval(subs(f,x,sym(xn)))) == sign(eval(subs(f,x,sym(xn+tstep))))
            xn = xn + tstep;
        else
            if tstep <= eps
                fprintf('Rasta saknis x = %f (tikslumas %f)\n', (xn+xn+tstep)/2, abs(tstep/2));
                ats = plot((xn+xn+tstep)/2,eval(subs(f,x,sym((xn+xn+tstep)/2))),'ms','MarkerSize',10,'LineWidth',2);
                xn = xn + tstep*2;
                tstep = step;
                continue;
            end
            tstep = tstep / 2;
        end
        pause(0.1)
    end
    
    legend([h1,h2,h(1),h(2),ats], 'funkcijos grafikas', 'f-jos x = 0 grafikas', 'intervalo pradzia', 'intervalo pabaiga', 'saknis');
    delete(h(1:2));

end