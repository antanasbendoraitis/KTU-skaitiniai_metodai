%
% Vienos lygties sprendimas: Niutono metodas
% 
function Niutonas
clc, close all

syms f x 

% f = x.^4-6*x.^3+3*x.^2+10*x;
% x0 = -3;
% alpha = 1;
% range = [-abs(x0),abs(x0)];

f = sin(x) * (x.^2 -1) * (x + 3) - 0.9;
x0 = 0.7;
alpha = 0.5;
range = [-10,10];

eps = 1e-9;

df = diff(f,x);

% braizomas funkcijos grafikas
npoints = 1000;

xrange = range(1) : (range(2)-range(1))/(npoints-1) : range(2);  
figure(1); grid on; hold on;
str = [char(f),' = 0;   Niutono metodas'];
title(str);
h1 = plot(xrange,eval(subs(f,x,sym(xrange))),'r-');
h2 = plot(range,[0 0],'b-');
h3 = plot(x0,0,'mp','MarkerFaceColor','m');

input('Press ENTER to begin'), figure(1);

% lygties sprendimas
xn = x0; 
prec = 1;
nit = 0; 
nitmax = 100;
legend([h1,h2,h3], 'funkcijos grafikas', 'f-jos x = 0 grafikas', 'esamas taskas');
while prec > eps 
    nit = nit + 1;
    if nit > nitmax, fprintf('Virsytas leistinas iteraciju skaicius');break;end

    fxn = eval(subs(f,x,sym(xn)));
    dfxn = eval(subs(df,x,sym(xn)));
    xn1 = xn - alpha * fxn/dfxn;    % daugikliu alpha apribojamas x prieaugis
    
    h4 = plot([xn,xn,xn1],[0,fxn,0],'g-');
    delete(h3);
    h3 = plot(xn1,0,'mp','MarkerFaceColor','m');
    xn = xn1;
     
    pause(0.1)
        
    fxn = eval(subs(f,x,sym(xn)));
    prec = abs(fxn);
    fprintf(1,'iteracija %d  x =  %.12f  prec =  %.20f \n',nit,xn,prec);
    legend([h1,h2,h3,h4], 'funkcijos grafikas', 'funkcija x = 0', 'esamas taskas', '2 TE nariai');
    % TE - Teiloro eilute
end
h5 = plot(xn,fxn,'ms','MarkerSize',10,'LineWidth',2);
legend([h1,h2,h3,h4,h5], 'funkcijos grafikas', 'funkcija x = 0', 'esamas taskas', '2 TE nariai', 'atsakymas');
delete(h3);

xn
nit

end