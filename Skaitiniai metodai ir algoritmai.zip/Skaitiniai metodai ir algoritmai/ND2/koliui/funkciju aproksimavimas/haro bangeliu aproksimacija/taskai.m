img = imread('img.png');
imagesc(img);
[x,y] = ginput(200) 
% Is failu ivedami duomenys: 
